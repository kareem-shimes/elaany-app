globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/94d7fa26a1dbd99f.js",
      "static/chunks/turbopack-f3ed83fac0ebc3a1.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/94d7fa26a1dbd99f.js",
      "static/chunks/turbopack-8ec130e51578d244.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c62b4372c26b460f.js",
    "static/chunks/5564f493499345f1.js",
    "static/chunks/7880f8283a6f3daf.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-b6a23b3e2832b47b.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];