__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/94d7fa26a1dbd99f.js",
  "static/chunks/turbopack-f3ed83fac0ebc3a1.js"
])
