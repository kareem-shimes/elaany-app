__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/94d7fa26a1dbd99f.js",
  "static/chunks/turbopack-8ec130e51578d244.js"
])
